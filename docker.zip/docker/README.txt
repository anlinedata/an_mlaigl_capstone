Folder Structure

Main Application
		-> docker/app
Main Application File
		-> docker/app/main.py
Main Application Port
		-> 8501
Docker Setup Process
		-> docker/app/BuildDockerContainer.txt
Docker File
		-> docker/Dockerfile
Docker Requirements
		->requirements.txt
